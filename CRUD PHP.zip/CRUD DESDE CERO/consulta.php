 <?php
 include('action.php');
?>

<!DOCTYPE html>
<html>
<head>
  <title>crud</title>
  <link rel="stylesheet" type="text/css" href="estilo.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

</head>
 
<body>

 <nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
  <a class="navbar-brand" href="index.php">CRUD</a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- PASE EL CODIGO DE WW3SCHOOLS-->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">SERVICIOS</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">PRODUCTOS</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">CONTACTOS</a>
      </li>
    </ul>
  </div>
  <form class="form-inline" action="/action_page.php">
    <input class="form-control mr-sm-2" type="text" placeholder="Search">
    <button class="btn btn-primary" type="submit">Search</button>
  </form>
</nav><br><br><br>
<div class="container">
 <div class="row justify-content-center">
<div class="col-md-6 mt-3 p-2 rounded" class="text-info">
  <!--++++++++++++++++++++++++++++++++++++++consulta++++++++++++++++++++++++++++++++++++++++++++++-->
<?php
      $registros=mysqli_query($conexion,"select codigo,nombre,mail,codigocurso
                           from alumnos where codigo='$_REQUEST[consulta]'") or
         die("problemas en el select:".mysqli_error($conexion));
  
           if ($row=mysqli_fetch_array($registros))
           {
              $id=$row['codigo'];
               $nombre=$row['nombre'];
                $mail=$row['mail'];
                 $codigo=$row['codigocurso'];

      
 

           echo "<h2 class=\"bg-primary p-2 rounded text-center text-dark\">CODIGO: $id</h2>"."<br>";
        
          echo "<div class=\"p-3 mb-2 bg-success text-white\">NOMBRE:</b> $nombre</div>"."<br>";
          echo "<div class=\"p-3 mb-2 bg-danger text-white\">MAIL:</b> $mail</div>"."<br>";
          echo "<div class=\"p-3 mb-2 bg-warning text-dark\">NOMBRE CURSO:";
                switch ($codigo) {
              case 1:echo "PHP";
                break;
                case 2:echo "ASP";
                break;
                case 3:echo "JSP</font></div>";
                break;
             } 
           
           }


           else{
            echo"<h2 class=\"text-danger\">No existe un alumno con ese nombre";
           }
             mysqli_close($conexion);

 ?>
 
</div>
</div> 
</div>
</body>
</html>

