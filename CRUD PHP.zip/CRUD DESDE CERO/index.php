
<?php
 include('action.php');
 error_reporting(51);
  ?>

<!DOCTYPE html>
<html>
<head>
	<title>crud</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

</head>
<style>
  
.background:(imagen/ima.jpg);


</style>
 
<body>

 <nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
  <a class="navbar-brand" href="index.php">CRUD</a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- PASE EL CODIGO DE WW3SCHOOLS-->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">SERVICIOS</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">PRODUCTOS</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">CONTACTOS</a>
      </li>
    </ul>
  </div>
  <form class="form-inline" action="/action_page.php">
    <input class="form-control mr-sm-2" type="text" placeholder="Search">
    <button class="btn btn-primary" type="submit">Search</button>
  </form>
</nav>
<div class="container-fluid">
	<div class="row justify-content-center">
		<div class="col-md-10">
			<h3 class="text-center text-info  mt-3"><em>INSTITUCION EDUCATIVA</em></h3>
			<!--codigo de bootstrap para mostrar una alerta-->
			<hr>
			<?php if($_SESSION['response']){ ?>
	         <div class=" alert alert-<?= $_SESSION['res_type'];?>alert-dismissible text-center">
             <button type="button" class="close" data-dismiss="alert">&times;</button>
           <?= $_SESSION['response'];?>
            </div>
<!--************************-->
              <?php } unset($_SESSION['response']);?>  
		</div>
	</div>
	<div class="row">
		<div class="col-md-4">
		 
          <h3 class="text-center text-info"><em>ALTA DE ALUMNOS</em></h3>
          <form action="action.php" method="post" enctype="multipart/form-data">
          	<input type="hidden" name="id" value="<?= $id; ?>">
          	<div class="form-group">
          	Ingrese nombre:&nbsp&nbsp&nbsp <br>
            <input type="text" name="nombre" value="<?= $nombre; ?>" class="form-control" placeholder="enter name" required><br>
           </div>

           	<div class="form-group">
             Ingrese mail:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<br>
            <input type="text" name="mail" value="<?= $mail; ?>" class="form-control" placeholder="enter email" required><br>
           </div>


        	<div class="form-group" value="<?= $codigocurso; ?>">
            Seleccione el curso:
            <select name="codigocurso" class="form-control"><br>
             <option value="1">PHP</option>
            <option value="2">ASP</option>
            <option value="3">JSP</option>
            </select>
           </div>

 
           <!--<div class="form-group">
           <input type="file" name="image" class="custom-file"><br>
           </div>-->
   
            <div class="form-group">
            	<?php if($update==true){ ?>
            	<input type="submit" name="actual" class="btn btn-success btn-block" values="actualizar">
            	<?php } else{ ?>	
              <input type="submit" name="add" class="btn btn-primary btn-block"values="registrar">
          <?php } ?>
            </div>
        </form>
	</div>
   <div class="col-md-8">
			<?php 
               $registros=mysqli_query($conexion,"select codigo,nombre,mail,
	codigocurso
                           from alumnos") or
	die("problemas en el select:".mysqli_error($conexion));
            $numero=0;  
              ?>
			<h3 class="text-center text-info mt-3"  ><em>RESGISTROS EXISTENTES EN LA BASE DE DATOS</em></h3>

			<table class="table table-hover">
    <thead>
      <tr>
        <th>codigo</th>
        <th>nombre</th>
        <th>mail</th>
        <th>codigocurso</th>
      </tr>
    </thead>
    <tbody>
    	<?php while ($reg=mysqli_fetch_array($registros)){?>
      <tr>
        <td> <?php echo  $reg['codigo'];?></td>
        <td> <?php echo $reg['nombre'];?></td>
        <td> <?php echo $reg['mail'];?></td>
        <td> <?php echo $reg['codigocurso'];?></td>
         <?php $numero++;?>
        <td>
        <a href="consulta.php?consulta=<?php echo $reg['codigo'];?>" class="badge badge-primary p-2">consulta</a>
        <a href="pagina2.php?eliminar=<?php echo $reg['codigo'];?>" class="badge badge-danger p-2" onclick="return confirm('desea eliminar este resgistro?');">eliminar</a>
        <a href="index.php?actualizar=<?php echo $reg['codigo'];?>" class="badge badge-success p-2">actualizar</a>
        </td>     
      </tr>
     <?php }?>
      </tbody>
      <hr>
     <tr> <h5 class="text-left text-info  mt-1"><em><?php echo "registros Nº  ".$numero?></em></h5></tr>
    </table>
		</div>
		</div>
        </div>




<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

</body>
</html>