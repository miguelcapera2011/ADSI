package PresentacionGlobant;

import java.util.Map;
import java.util.TreeMap;

public class ColeccionTreeMap {

    public static void main(String[] args) {

        // Creacion del TreeMap

        Map<String, String> departamentos = new TreeMap<String, String>();


        // Inserto elementos al map
        departamentos.put("Tolima", "Ibague");
        departamentos.put("Guania", "Inirida");
        departamentos.put("Boyaca", "Tunja");
        departamentos.put("Huila", "Neiva");
        departamentos.put("Vaupes", "Mitu");
        departamentos.put("Amazonas", "Leticias");
        departamentos.put("Sucre", "sincelo");
        departamentos.put("Meta", "Villavicencio");
        departamentos.put("Putumayo", "Mocoa");
        departamentos.put("Caldas", "Manizales");

        System.out.println("Map: " + departamentos);


        // claves de acceso al mapa
        System.out.println("Claves: " + departamentos.keySet());


        // valores de acceso al mapa
        System.out.println("Valores: " + departamentos.values());


        // acceder a las entradas del mapa
        System.out.println("Entradas: " + departamentos.entrySet());


        //  Eliminar elementos del mapa
        String value = departamentos.remove("Caldas");

        System.out.println("Valor eliminado: " + value);



    }
    }
