<?php

   $conexion=mysqli_connect("localhost","root","","base1")or
      die("problemas con la conexion");
 
?>