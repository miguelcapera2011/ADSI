import javax.swing.*;

public class formulario {
    private JPanel panel1;
    private JTextField Registro;
    private JButton button1;
}

