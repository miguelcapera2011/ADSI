var operandoa;
var operacion;

function init(){
    //variables
    var resultado=document.getElementById("resultado");
    //Botone de celsius
    var celsius=document.getElementById("c");
    var uno=document.getElementById('uno');
    var dos=document.getElementById('dos');
    var tres=document.getElementById('tres');
    var cuatro=document.getElementById('cuatro');
    var cinco=document.getElementById('cinco');
    var seis=document.getElementById('seis');
    var siete=document.getElementById('siete');
    var ocho=document.getElementById('ocho');
    var nueve=document.getElementById('nueve');
    var cero=document.getElementById('cero');
    //Botone farenheite
    var farenheite=document.getElementById('f');
    //Botone rankine
    var rankine=document.getElementById('r');
    //Botone de limpiar
    var reset=document.getElementById('limpiar');

   //eventos
 
   uno.onclick=function(e){
       resultado.textContent=resultado.textContent="1";
      
   }

   dos.onclick=function(e){
    resultado.textContent=resultado.textContent="2";
}

tres.onclick=function(e){
    resultado.textContent=resultado.textContent="3";
}

cuatro.onclick=function(e){
    resultado.textContent=resultado.textContent="4";
}

cinco.onclick=function(e){
    resultado.textContent=resultado.textContent="5";
}

seis.onclick=function(e){
    resultado.textContent=resultado.textContent="6";
}

siete.onclick=function(e){
    resultado.textContent=resultado.textContent="7";
}

ocho.onclick=function(e){
    resultado.textContent=resultado.textContent="8";
}

nueve.onclick=function(e){
    resultado.textContent=resultado.textContent="9";
}

cero.onclick=function(e){
    resultado.textContent=resultado.textContent="0";
}
 
reset.onclick=function(e){
    clear();
}


farenheite.onclick=function(e){

    operandoa = resultado.textContent;
   operacion= "f";
   resolver();
}

rankine.onclick=function(e){

    operandoa = resultado.textContent;
   operacion="r";
   resolver();
}

celsius.onclick=function(e){

    operandoa = resultado.textContent;
   operacion= "c";
   resolver();
}
  
function clear(){
    resultado.textContent="";
    var elemento=document.getElementById("foto");
    elemento.src="imagenes/code.gif";
   
 

}

function resolver(){
  var res=0;
  switch(operacion){
      case"c":
      res=((operandoa*9)/5)+32;
      break;
      case"f":
      res=Math.round((((operandoa-32)*5)/9));
      break;
      case"r":
      res=(operandoa- 459.67);
      break;
  }
  resultado.textContent=res;
}


}
 

function miFuncion(){
 
  var elemento=document.getElementById("foto");
  elemento.src="imagenes/celsiu.jpg";
 
}

function miFuncion1(){
 
    var elemento=document.getElementById("foto");
    elemento.src="imagenes/re.jpg";
   
  }

  function miFuncion2(){
 
    var elemento=document.getElementById("foto");
    elemento.src="imagenes/fah.jpg";
   
  }