package PresentacionGlobant;

import java.util.Map;
import java.util.TreeMap;

public class Ejemplo {
    public static void main(String[] args) {

        Map<Integer ,String> numeros=new TreeMap<>();
        numeros.put(1,"uno");
        numeros.put(5,"cinco");
        numeros.put(2,"dos");
        numeros.put(4,"cuatro");
        numeros.put(3,"tres");

        System.out.println();
    }

}
