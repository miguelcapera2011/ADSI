
<?php
session_start();
/*-----------la conexion esterna------------*/
include('config.php');

$update=false;
$id="";
$nombre="";
$mail="";
$codigocurso="";
/*--------orden insert ingresar valores-----------------*/
if(isset($_POST['add'])){
$nombre=$_POST['nombre'];
$mail=$_POST['mail'];
$codigocurso=$_POST['codigocurso'];

mysqli_query($conexion, "insert into alumnos(nombre,mail,codigocurso) values 
                       ('$nombre','$mail',$codigocurso)")
or die("Problemas en el select" . mysqli_error($conexion));
mysqli_close($conexion);
header('location:index.php');
$_SESSION['response']="<b><h2>Registros Insertados con exito</h2></b>";
$_SESSION['res_type']="success";
}
/*-----EL OBJETIVO ES MODIFICAR LOS DATOS EN EL MISMO FORMULARIO------*/
/*-----primera parte para mostra los datos en el formulario------*/
if(isset($_GET['actualizar'])){
$id=$_GET['actualizar'];
 $registros=mysqli_query($conexion,"select * from alumnos 
                                      where codigo='$id'") or
         die("problemas en el select:".mysqli_error($conexion));

       $row=mysqli_fetch_array($registros);
 
$id=$row['codigo'];
$nombre=$row['nombre'];
$mail=$row['mail'];
$codigocurso=$row['codigocurso'];
$update=true;

 }

/*-----------segunda parte done los datos modificados los envio a la base de datos-------------*/
if(isset($_POST['actual'])){
$id=$_POST['id'];	
$nombre=$_POST['nombre'];
$mail=$_POST['mail'];
$codigocurso=$_POST['codigocurso'];
  mysqli_query($conexion, "update alumnos 
        	               set nombre='$nombre',mail='$mail',codigocurso='$codigocurso'
                           where codigo='$id'") or
	       die ("problemas en el select:".mysqli_error($conexion));
	       
      header('location:index.php');
}
 

 