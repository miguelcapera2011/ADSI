<html>
<head>
<meta charset="utf-8"> 
  <link rel="stylesheet"type="text/css"href="">
  <title>delete</title>
</head>
  
 <body>
  <?php
  include('config.php');


if(isset($_GET['eliminar'])){   
  $registros = mysqli_query($conexion, "select codigo from alumnos
                        where codigo='$_GET[eliminar]'") or
    die("Problemas en el select:" . mysqli_error($conexion));
  if ($reg = mysqli_fetch_array($registros)) {
    mysqli_query($conexion, "delete from alumnos where codigo='$_GET[eliminar]'") or
      die("Problemas en el select:" . mysqli_error($conexion));
  }  
  mysqli_close($conexion);

 header('location:index.php');
}

  ?>
</body>
  </html>